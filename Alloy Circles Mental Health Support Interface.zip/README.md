# Steps to run this prototype
- Install [Bun](https://bun.com/docs/installation)
- Open a new terminal window
- Run `bun install && bun run dev` in this directory
- Open [http://localhost:5173](http://localhost:5173) in your browser