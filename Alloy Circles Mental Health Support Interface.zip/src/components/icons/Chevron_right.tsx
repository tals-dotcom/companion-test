import type { JSX } from 'react/jsx-runtime'


import React from 'react';

export const Chevron_right = () => {
    return (
<svg data-v-53aaf1d1={""} xmlns={"http://www.w3.org/2000/svg"} width={"7"} height={"12"} viewBox={"0 0 7 12"} fill={"none"}>
<path data-v-53aaf1d1={""} d={"M0.75 10.75L5.75 5.75L0.75 0.75"} stroke={"#44403C"} strokeWidth={"1.5"} strokeLinecap={"round"} strokeLinejoin={"round"}></path>
</svg>    );
}



export default Chevron_right
