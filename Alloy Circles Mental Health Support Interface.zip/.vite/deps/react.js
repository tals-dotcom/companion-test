import {
  require_react
} from "./chunk-MSOB5AQU.js";
import "./chunk-G3PMV62Z.js";
export default require_react();
//# sourceMappingURL=react.js.map
